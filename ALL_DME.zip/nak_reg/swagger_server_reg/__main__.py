#!/usr/bin/env python3

import connexion

from swagger_server_reg import encoder

import logging

logging.basicConfig(level=logging.DEBUG)

def main():
    app = connexion.App(__name__, specification_dir='./swagger/')
    app.app.json_encoder = encoder.JSONEncoder
    app.add_api('swagger.yaml', arguments={'title': 'Data registration service'}, pythonic_params=True)
    app.run(port=5001)


if __name__ == '__main__':
    main()
